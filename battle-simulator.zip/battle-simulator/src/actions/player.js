
export const movieAction = (movieName) => dispatch => {
    dispatch({
        type: 'GET_MOVIE_DES',
        payload: `Decription ... for Movie ${movieName}`
    })
}