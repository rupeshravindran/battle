function updateMessage(message) {
    return {
      type: ADD_TODO,
      text
    }
  }