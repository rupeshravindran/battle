const intialState = {
    players: [
      {
        name: 'Player1',
        avatar: '',
        remainingHealth: 100,
        healthLostInPreviousRound: 0,
        weapons:[{
          id: '#1',
          point: 1
        }, {
            id: '#2',
            point: 1
        }],
      },
      {
        name: 'Player2',
        avatar: '',
        remainingHealth: 100,
        healthLostInPreviousRound: 0,
        weapons:[{
          id: '#3',
          point: 1
        }, {
            id: '#4',
            point: 1
        }],
      }
    ]
  }

export default function player(state = intialState, action) {
    switch (action.type) {
        case 'UPDATE_HEALTH':
            return state;
        case 'UPDATE_DICE_POINTS':
            return state;
        default:
            return state
    }
}