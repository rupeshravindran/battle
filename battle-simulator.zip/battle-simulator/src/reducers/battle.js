const intialState = {
    battleState: 'idle',
    round: '',
    currentPlayer: '',
    winner: '',
    message: 'Click attack button to roll dice'
}

export default function battle(state = intialState, action) {
    switch (action.type) {
        case 'UPDATE_BATTLE_STATE':
            return state;
        case 'UPDATE_BATTLE_WINNER':
            return state;
        default:
            return state
    }
}