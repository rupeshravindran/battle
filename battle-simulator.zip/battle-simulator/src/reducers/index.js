import { combineReducers } from 'redux'
import battle from './battle'
import player from './player'


export default combineReducers({
  battle,
  player
})