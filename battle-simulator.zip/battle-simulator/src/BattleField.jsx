import { React } from 'react';
import './BattleField.css';

export default function BattleField() {
    return (<div>Battle Field</div>)
}
