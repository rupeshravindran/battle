import { React } from 'react';
import './Avatar.css';

export Default function Avatar({ title, imageSource}) {
    
}