import { React } from 'react';
import './Health.css';

export Default function Health({ remainingHealth, healthLostInPreviousRound }) {
    
}