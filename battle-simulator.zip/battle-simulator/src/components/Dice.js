import { React } from 'react';
import './Dice.css';

export Default function Dice({ points, round }) {
    
}