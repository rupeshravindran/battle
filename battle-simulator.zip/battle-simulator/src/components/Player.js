import { React } from 'react';
import './Player.css';

export Default function Player({ player }) {
    
}